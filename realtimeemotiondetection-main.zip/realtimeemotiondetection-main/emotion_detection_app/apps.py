from django.apps import AppConfig


class EmotionDetectionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'emotion_detection_app'
